<?php

declare(strict_types=1);

namespace Capsolver\Exceptions;

class ResponseException extends CapsolverException
{

}