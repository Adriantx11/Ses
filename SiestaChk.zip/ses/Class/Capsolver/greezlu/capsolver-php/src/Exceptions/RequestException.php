<?php

declare(strict_types=1);

namespace Capsolver\Exceptions;

class RequestException extends CapsolverException
{

}