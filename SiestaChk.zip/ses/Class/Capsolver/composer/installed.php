<?php return array(
    'root' => array(
        'name' => '__root__',
        'pretty_version' => '1.0.0+no-version-set',
        'version' => '1.0.0.0',
        'reference' => null,
        'type' => 'library',
        'install_path' => __DIR__ . '/../../',
        'aliases' => array(),
        'dev' => true,
    ),
    'versions' => array(
        '__root__' => array(
            'pretty_version' => '1.0.0+no-version-set',
            'version' => '1.0.0.0',
            'reference' => null,
            'type' => 'library',
            'install_path' => __DIR__ . '/../../',
            'aliases' => array(),
            'dev_requirement' => false,
        ),
        'greezlu/capsolver-php' => array(
            'pretty_version' => '0.9.2',
            'version' => '0.9.2.0',
            'reference' => 'ed0682790f181deb0b39cedf857c71192b45963b',
            'type' => 'library',
            'install_path' => __DIR__ . '/../greezlu/capsolver-php',
            'aliases' => array(),
            'dev_requirement' => false,
        ),
    ),
);
